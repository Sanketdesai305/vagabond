package com.example.dheeraj.vagabond;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

/**
 * Created by Dheeraj
 */

public class login extends AppCompatActivity
{
    EditText email,pass;
    Button login;
    ProgressDialog pd;
    TextView reg,skip;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email=(EditText)findViewById(R.id.email);
        pass=(EditText)findViewById(R.id.pass);
        login=(Button)findViewById(R.id.login);
        reg=(TextView)findViewById(R.id.reg);
        pd=new ProgressDialog(login.this);
        pd.setIndeterminate(true);
        pd.setMessage("Please wait...");
        pd.setCancelable(false);

        SharedPreferences sp=getSharedPreferences("pref",MODE_PRIVATE);
        if(sp.contains("id"))
        {
            Intent i=new Intent(login.this,activity_main.class);
            startActivity(i);
            finish();
        }

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(login.this,Registration.class);
                startActivity(i);

            }
        });
        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(login.this,activity_main.class);
                startActivity(i);
                finish();
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!validateemail())
                {
                    return;
                }
                if(!validatepass())
                {
                    return;
                }
                ConnectivityManager connMgr1 = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo networkInfo1 = connMgr1.getActiveNetworkInfo();
                if (networkInfo1 != null && networkInfo1.isConnected()) {
                    loginuser();
                }else {
                    Toast.makeText(login.this, "Internet Connection Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public void loginuser()
    {
        AsyncHttpClient client=new AsyncHttpClient();
        RequestParams params=new RequestParams();
        params.put("email",email.getText().toString());
        params.put("pass",pass.getText().toString());

        client.post(CommanUtils.url+"login.php",params,new JsonHttpResponseHandler()
        {
            @Override
            public void onStart() {
                super.onStart();
                pd.show();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                super.onSuccess(statusCode, headers, response);
                pd.dismiss();
                try {
                    if(response.getString("responce").equals("Success"))
                    {
                        JSONArray ja=response.getJSONArray("data");
                        for (int i = 0; i <ja.length() ; i++)
                        {
                            JSONObject jo=ja.getJSONObject(i);
                            SharedPreferences sp=getSharedPreferences("pref",MODE_PRIVATE);
                            SharedPreferences.Editor ed=sp.edit();
                            ed.putString("name",jo.getString("name"));
                            ed.putString("id",jo.getString("id"));
                            ed.putString("email",jo.getString("email"));
                            ed.apply();

                            Intent j=new Intent(login.this,activity_main.class);
                            startActivity(j);
                        }
                    }
                    else {
                        Toast.makeText(login.this, response.getString("responce"), Toast.LENGTH_LONG).show();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                super.onFailure(statusCode, headers, responseString, throwable);
                pd.dismiss();
                Toast.makeText(login.this, statusCode+" error", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public boolean validateemail()
    {
        if(email.getText().toString().isEmpty() || !checkemail(email.getText().toString()))
        {
            email.setError("Email Required");
            return false;
        }
        return true;
    }
    public boolean validatepass()
    {
        if(pass.getText().toString().isEmpty())
        {
            pass.setError("Password Required");
            return false;
        }
        return true;
    }
    public boolean checkemail(String em)
    {
        return Patterns.EMAIL_ADDRESS.matcher(em).matches();
    }
}

package com.example.dheeraj.vagabond;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

/**
 * Created by Dheeraj
 */

public class Registration extends AppCompatActivity
{
    EditText name,email,mobile,pass;
    Button reg;
    ProgressDialog pd;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration);

        name=findViewById(R.id.name);
        email=findViewById(R.id.email);
        mobile=findViewById(R.id.mobile);
        pass=findViewById(R.id.pass);
        reg=findViewById(R.id.register);
        pd=new ProgressDialog(Registration.this);
        pd.setIndeterminate(true);
        pd.setMessage("Please wait...");
        pd.setCancelable(false);

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!validatename())
                {
                    return;
                }
                if(!validateemail())
                {
                    return;
                }
                if(!validatemobile())
                {
                    return;
                }
                if(!validatepass())
                {
                    return;
                }
                {


                    AsyncHttpClient client=new AsyncHttpClient();
                    RequestParams params=new RequestParams();
                    params.put("name",name.getText().toString());
                    params.put("mobile",mobile.getText().toString());
                    params.put("email",email.getText().toString());
                    params.put("pass",pass.getText().toString());
                    client.post(CommanUtils.url+"registration.php",params,new JsonHttpResponseHandler()
                    {
                        @Override
                        public void onStart() {
                            super.onStart();
                            pd.show();
                        }

                        @Override
                        public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                            super.onSuccess(statusCode, headers, response);
                            pd.dismiss();
                            try {
                                Toast.makeText(Registration.this, response.getString("responce"), Toast.LENGTH_SHORT).show();
                                if(response.getString("responce").equals("Registration Successfully"))
                                {
                                    Intent i=new Intent(Registration.this,login.class);
                                    startActivity(i);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                            super.onFailure(statusCode, headers, responseString, throwable);
                            pd.dismiss();
                            Toast.makeText(Registration.this, statusCode+"Error", Toast.LENGTH_SHORT).show();
                        }
                    });}
                else
                {
                    Toast.makeText(Registration.this, "Internet Connection Not Available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public boolean validatename()
    {
        if(name.getText().toString().isEmpty())
        {
            name.setError("Name Required");
            return false;
        }
        return true;
    }
    public boolean validatemobile()
    {
        if(mobile.getText().toString().isEmpty() ||!(mobile.getText().toString().length()==10))
        {
            mobile.setError("Mobile Required");
            return false;
        }
        return true;
    }
    public boolean validateemail()
    {
        if(email.getText().toString().isEmpty() || !checkemail(email.getText().toString()))
        {
            email.setError("Email Required");
            return false;
        }
        return true;
    }
    public boolean validatepass()
    {
        if(pass.getText().toString().isEmpty())
        {
            pass.setError("Password Required");
            return false;
        }
        return true;
    }
    public boolean checkemail(String em)
    {
        return Patterns.EMAIL_ADDRESS.matcher(em).matches();
    }
}


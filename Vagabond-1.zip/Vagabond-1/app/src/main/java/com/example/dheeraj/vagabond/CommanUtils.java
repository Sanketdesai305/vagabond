package com.example.dheeraj.vagabond;

public class CommanUtils
{
    public static final String url="http:192.168.150.18/vagabond/";
}

